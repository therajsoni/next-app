# Next Dev Builder

A JavaScript-only Next.js 16 app that demonstrates the configuration-driven system discussed in the project design:

- `/next-dev` = visual builder/control panel
- MongoDB-only persistence
- Services with MongoDB field types and CRUD flags
- API builder for GET/POST/PUT/PATCH/DELETE definitions
- Runtime API at `/api/runtime/[service]/[[...path]]`
- Runtime preview at `/preview`
- 47 frontend/UI categories registered as a searchable catalog
- Tailwind CSS v4
- shadcn-style UI primitives + `components.json`

## Setup

Requirements: Node.js 20.9+ and MongoDB.

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open:

- http://localhost:3000/next-dev
- http://localhost:3000/preview

## MongoDB

Default local connection:

```env
MONGODB_URI=mongodb://127.0.0.1:27017
MONGODB_DB=next_dev_builder
```

The application creates these collections as they are used:

- `projects`
- `services`
- `apiDefinitions`
- one collection per created service (for example `users`)

## Service example

Create `User Service` with:

- `_id` -> ObjectId
- `name` -> String
- `username` -> String
- `email` -> Email
- `phone` -> Phone
- `isActive` -> Boolean
- `createdAt` -> Date

Then create a GET API definition from `/next-dev`.

## Runtime API examples

After creating a service with slug `user-service` and collection `users`:

```bash
curl http://localhost:3000/api/runtime/user-service?limit=20&sort=createdAt&order=desc
curl -X POST http://localhost:3000/api/runtime/user-service \
  -H 'content-type: application/json' \
  -d '{"name":"Raj","username":"raj","email":"raj@example.com"}'
```

For an item:

```bash
curl http://localhost:3000/api/runtime/user-service/<object-id>
curl -X PATCH http://localhost:3000/api/runtime/user-service/<object-id> \
  -H 'content-type: application/json' \
  -d '{"name":"Updated"}'
curl -X DELETE http://localhost:3000/api/runtime/user-service/<object-id>
```

## Important architecture note

This starter does not magically create arbitrary source code from configuration. Instead, it provides a pre-built runtime/component registry that reads MongoDB configuration and renders the matching UI/behavior. This is the core pattern needed for a configuration-driven `/next-dev` builder.

For production, add authentication/authorization, schema validation, rate limits, audit logs, API versioning, and stricter query allowlists before exposing generated runtime APIs publicly.

The catalog mirrors the user-provided frontend inventory of 47 categories and their items.
