import { ObjectId } from 'mongodb';
import { getCollection } from '@/lib/mongodb';

function parseValue(type, value) {
  if (value == null) return value;
  if (type === 'Number') return Number(value);
  if (type === 'Boolean') return value === 'true' || value === true;
  if (type === 'ObjectId') return ObjectId.isValid(value) ? new ObjectId(value) : value;
  if (type === 'Date') return new Date(value);
  return value;
}

async function getService(slug) {
  return (await getCollection('services')).findOne({ slug });
}

async function getGetDefinition(service) {
  const definitions = await getCollection('apiDefinitions');
  return definitions.findOne({ serviceId: service._id.toString(), method: 'GET' }, { sort: { createdAt: -1 } });
}

async function run(request, { params }) {
  const p = await params;
  const service = await getService(p.service);
  if (!service) return Response.json({ error: 'Service not found' }, { status: 404 });

  const collection = await getCollection(service.collection);
  const path = p.path || [];
  const id = path[0];
  const method = request.method;
  const url = new URL(request.url);
  const definition = method === 'GET' ? await getGetDefinition(service) : null;

  const filter = {};
  for (const field of service.fields || []) {
    const raw = url.searchParams.get(field.name);
    if (raw !== null) filter[field.name] = parseValue(field.type, raw);
  }

  if (definition?.search && url.searchParams.get('search')) {
    const q = url.searchParams.get('search');
    const stringFields = (service.fields || []).filter((f) => ['String','Email','Phone','URL'].includes(f.type)).map((f) => f.name);
    if (stringFields.length) filter.$or = stringFields.map((name) => ({ [name]: { $regex: q, $options: 'i' } }));
  }

  if (method === 'GET') {
    if (id) {
      if (!ObjectId.isValid(id)) return Response.json({ error: 'Valid ObjectId required' }, { status: 400 });
      const doc = await collection.findOne({ _id: new ObjectId(id) });
      return Response.json(doc || { error: 'Not found' }, { status: doc ? 200 : 404 });
    }

    const sortField = definition?.sort ? url.searchParams.get('sort') : null;
    const sortDir = url.searchParams.get('order') === 'desc' ? -1 : 1;
    const limitEnabled = definition ? definition.limit !== false : true;
    const skipEnabled = definition ? definition.skip === true : true;
    const limit = limitEnabled ? Math.min(Math.max(Number(url.searchParams.get('limit') || 50), 1), 200) : 50;
    const skip = skipEnabled ? Math.max(Number(url.searchParams.get('skip') || 0), 0) : 0;
    const projection = definition?.fields?.length ? Object.fromEntries(definition.fields.map((name) => [name, 1])) : undefined;

    let cursor = collection.find(filter, projection ? { projection } : undefined).skip(skip).limit(limit);
    if (sortField) cursor = cursor.sort({ [sortField]: sortDir });
    const [items, total] = await Promise.all([cursor.toArray(), collection.countDocuments(filter)]);
    return Response.json({ items, total, limit, skip });
  }

  if (method === 'POST') {
    const body = await request.json();
    const result = await collection.insertOne(body);
    return Response.json({ insertedId: result.insertedId, ...body }, { status: 201 });
  }

  if (method === 'PUT' || method === 'PATCH') {
    if (!id || !ObjectId.isValid(id)) return Response.json({ error: 'Valid id required' }, { status: 400 });
    const body = await request.json();
    const result = await collection.updateOne({ _id: new ObjectId(id) }, { $set: body });
    return Response.json({ matchedCount: result.matchedCount, modifiedCount: result.modifiedCount });
  }

  if (method === 'DELETE') {
    if (!id || !ObjectId.isValid(id)) return Response.json({ error: 'Valid id required' }, { status: 400 });
    const result = await collection.deleteOne({ _id: new ObjectId(id) });
    return Response.json({ deletedCount: result.deletedCount });
  }

  return Response.json({ error: 'Method not supported' }, { status: 405 });
}

export const GET = run;
export const POST = run;
export const PUT = run;
export const PATCH = run;
export const DELETE = run;
