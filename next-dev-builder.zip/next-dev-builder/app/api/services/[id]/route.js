import { ObjectId } from 'mongodb';
import { getCollection } from '@/lib/mongodb';
import { serialize } from '@/lib/serialize';

function toId(id) { return ObjectId.isValid(id) ? new ObjectId(id) : null; }

export async function GET(_request, { params }) {
  const id = toId((await params).id);
  if (!id) return Response.json({ error: 'Invalid id' }, { status: 400 });
  const service = await (await getCollection('services')).findOne({ _id: id });
  if (!service) return Response.json({ error: 'Not found' }, { status: 404 });
  return Response.json(serialize(service));
}

export async function PATCH(request, { params }) {
  const id = toId((await params).id);
  if (!id) return Response.json({ error: 'Invalid id' }, { status: 400 });
  const body = await request.json();
  await (await getCollection('services')).updateOne({ _id: id }, { $set: { ...body, updatedAt: new Date() } });
  const service = await (await getCollection('services')).findOne({ _id: id });
  return Response.json(serialize(service));
}

export async function DELETE(_request, { params }) {
  const id = toId((await params).id);
  if (!id) return Response.json({ error: 'Invalid id' }, { status: 400 });
  await (await getCollection('services')).deleteOne({ _id: id });
  await (await getCollection('apiDefinitions')).deleteMany({ serviceId: id.toString() });
  return Response.json({ ok: true });
}
