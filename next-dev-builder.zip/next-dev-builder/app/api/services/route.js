import { getCollection } from '@/lib/mongodb';
import { serialize } from '@/lib/serialize';

export async function GET() {
  const services = await (await getCollection('services')).find({}).sort({ createdAt: -1 }).toArray();
  return Response.json(serialize(services));
}

export async function POST(request) {
  const body = await request.json();
  const collection = await getCollection('services');
  const now = new Date();
  const doc = {
    name: body.name,
    slug: body.slug || body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    collection: body.collection || body.name.toLowerCase().replace(/[^a-z0-9]+/g, '_'),
    database: 'mongodb',
    fields: body.fields || [],
    crud: body.crud || { create: true, getAll: true, getById: true, update: true, patch: true, delete: true },
    createdAt: now,
    updatedAt: now
  };
  const result = await collection.insertOne(doc);
  return Response.json(serialize({ ...doc, _id: result.insertedId }), { status: 201 });
}
