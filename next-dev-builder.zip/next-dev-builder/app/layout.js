import './globals.css';

export const metadata = {
  title: 'Next Dev Builder',
  description: 'Configuration-driven Next.js and MongoDB application builder'
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
