import BuilderShell from '@/components/builder/BuilderShell';

export default function NextDevPage() {
  return <BuilderShell />;
}
