import RuntimePreview from '@/components/builder/RuntimePreview';
export const dynamic = 'force-dynamic';
export default function PreviewPage() {
  return <RuntimePreview />;
}
