'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

export default function UsersPage() {
  const [service, setService] = useState(null);
  const [data, setData] = useState({ items: [], total: 0 });
  const [search, setSearch] = useState('');
  async function load() {
    const services = await fetch('/api/services').then(r => r.json());
    const s = services.find(x => x.slug === 'user-service') || services[0];
    setService(s || null);
    if (s) setData(await fetch(`/api/runtime/${s.slug}?limit=50${search ? `&search=${encodeURIComponent(search)}` : ''}`).then(r => r.json()));
  }
  useEffect(() => { load(); }, []);
  if (!service) return <div className="grid min-h-screen place-items-center"><Card><CardContent className="p-8 text-center">Create a service from <Link className="text-blue-600" href="/next-dev">/next-dev</Link>.</CardContent></Card></div>;
  return <div className="min-h-screen bg-slate-50 p-5 lg:p-8"><div className="mx-auto max-w-6xl space-y-5"><div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold">{service.name}</h1><p className="text-sm text-slate-500">Dynamic MongoDB runtime page</p></div><Link href="/next-dev"><Button variant="outline">Builder</Button></Link></div><Card><CardHeader><div className="flex items-center justify-between"><CardTitle>Records</CardTitle><div className="flex gap-2"><Input placeholder="Search" value={search} onChange={e=>setSearch(e.target.value)} /><Button onClick={load}>Search</Button></div></div></CardHeader><CardContent><div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead><tr>{(service.fields||[]).map(f=><th key={f.name} className="border-b px-3 py-3">{f.name}</th>)}</tr></thead><tbody>{data.items?.map((row,i)=><tr key={row._id || i} className="hover:bg-slate-50">{(service.fields||[]).map(f=><td key={f.name} className="border-b px-3 py-3">{String(row[f.name] ?? '')}</td>)}</tr>)}</tbody></table></div><div className="mt-4 text-xs text-slate-500">{data.total || 0} records</div></CardContent></Card></div></div>;
}
