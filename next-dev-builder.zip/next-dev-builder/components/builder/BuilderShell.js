'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Icon from './Icon';
import { catalog, itemCount } from '@/lib/catalog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog } from '@/components/ui/dialog';

const fieldTypes = ['String','Number','Boolean','ObjectId','Date','Email','Phone','URL','Array','Object'];
const initialField = { name: '', type: 'String', required: false, unique: false, defaultValue: '' };

export default function BuilderShell() {
  const [project, setProject] = useState(null);
  const [services, setServices] = useState([]);
  const [apis, setApis] = useState([]);
  const [tab, setTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [serviceOpen, setServiceOpen] = useState(false);
  const [apiOpen, setApiOpen] = useState(false);
  const [editingField, setEditingField] = useState(initialField);
  const [serviceForm, setServiceForm] = useState({ name: 'User Service', collection: 'users', fields: [
    { name: '_id', type: 'ObjectId', required: true, unique: true, defaultValue: '' },
    { name: 'name', type: 'String', required: true, unique: false, defaultValue: '' },
    { name: 'username', type: 'String', required: true, unique: true, defaultValue: '' },
    { name: 'email', type: 'Email', required: true, unique: true, defaultValue: '' },
    { name: 'phone', type: 'Phone', required: false, unique: false, defaultValue: '' },
    { name: 'isActive', type: 'Boolean', required: false, unique: false, defaultValue: 'true' },
    { name: 'createdAt', type: 'Date', required: true, unique: false, defaultValue: 'now' }
  ] });
  const [apiForm, setApiForm] = useState({ serviceId: '', method: 'GET', path: '', fields: [], search: true, filter: true, sort: true, limit: true, skip: false });

  async function load() {
    setLoading(true);
    const [p, s, a] = await Promise.all([fetch('/api/project').then(r => r.json()), fetch('/api/services').then(r => r.json()), fetch('/api/apis').then(r => r.json())]);
    setProject(p); setServices(s); setApis(a); setApiForm(v => ({ ...v, serviceId: v.serviceId || s[0]?._id || '' })); setLoading(false);
  }
  useEffect(() => { load().catch(() => setMessage('MongoDB connection failed. Check .env.local.')); }, []);

  const counts = useMemo(() => ({ categories: catalog.length, items: itemCount, services: services.length, apis: apis.length }), [services, apis]);

  async function saveProject() {
    const res = await fetch('/api/project', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(project) });
    if (res.ok) setMessage('Project configuration saved.');
  }

  async function createService() {
    const res = await fetch('/api/services', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(serviceForm) });
    if (res.ok) { setServiceOpen(false); setMessage('Service created.'); await load(); }
  }

  async function createApi() {
    const service = services.find(s => s._id === apiForm.serviceId);
    if (!service) return;
    const path = apiForm.path || `/api/runtime/${service.slug}`;
    const res = await fetch('/api/apis', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ ...apiForm, serviceName: service.name, path }) });
    if (res.ok) { setApiOpen(false); setMessage('API definition saved.'); await load(); }
  }

  async function deleteService(id) {
    await fetch(`/api/services/${id}`, { method: 'DELETE' });
    await load();
  }

  async function addField() {
    if (!editingField.name.trim()) return;
    setServiceForm(v => ({ ...v, fields: [...v.fields, editingField] }));
    setEditingField(initialField);
  }

  if (loading || !project) return <div className="flex min-h-screen items-center justify-center">Loading builder…</div>;

  const nav = project.navigation?.items || [];
  return <div className="min-h-screen bg-slate-50 text-slate-900">
    <header className="sticky top-0 z-30 border-b bg-white/95 backdrop-blur">
      <div className="flex h-16 items-center gap-4 px-5">
        <div className="flex items-center gap-2 font-semibold"><div className="grid h-9 w-9 place-items-center rounded-lg bg-blue-600 text-white">ND</div>Next Dev Builder</div>
        <Badge>{counts.categories} categories</Badge><Badge>{counts.items}+ UI items</Badge>
        <div className="ml-auto flex items-center gap-2">
          <Link href="/preview"><Button variant="outline" size="sm"><Icon name="Eye" size={16}/> Preview</Button></Link>
          <Button size="sm" onClick={saveProject}><Icon name="Save" size={16}/> Save</Button>
        </div>
      </div>
    </header>

    <div className="grid min-h-[calc(100vh-64px)] grid-cols-[250px_1fr]">
      <aside className="border-r bg-white p-3">
        <div className="mb-3 px-3 text-xs font-semibold uppercase tracking-wider text-slate-400">Builder</div>
        <div className="space-y-1">
          {[['overview','LayoutDashboard','Overview'],['project','Settings2','Project Settings'],['services','Boxes','Services & CRUD'],['apis','Webhook','API Builder'],['components','PanelsTopLeft','47 UI Categories']].map(([id,icon,label]) => (
            <button key={id} onClick={() => setTab(id)} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm ${tab===id?'bg-blue-50 text-blue-700':'hover:bg-slate-100'}`}><Icon name={icon} size={17}/>{label}</button>
          ))}
        </div>
        <div className="mt-6 border-t pt-4">
          <div className="px-3 text-xs font-semibold uppercase tracking-wider text-slate-400">Project</div>
          <div className="mt-2 px-3 text-sm font-medium">{project.name}</div>
          <div className="px-3 text-xs text-slate-500">MongoDB only</div>
        </div>
        <div className="mt-5 border-t pt-4">
          <div className="px-3 text-xs font-semibold uppercase tracking-wider text-slate-400">Runtime routes</div>
          {nav.slice(0, 6).map(item => <Link key={item.id} href={item.route || '#'} className="mt-1 block rounded px-3 py-2 text-sm text-slate-600 hover:bg-slate-100">{item.label}</Link>)}
        </div>
      </aside>

      <main className="p-5 lg:p-7">
        {message && <div className="mb-5 rounded-lg border border-blue-200 bg-blue-50 px-4 py-3 text-sm text-blue-700">{message}</div>}
        {tab === 'overview' && <Overview project={project} counts={counts} services={services} apis={apis} />}
        {tab === 'project' && <ProjectSettings project={project} setProject={setProject} />}
        {tab === 'services' && <ServicesPanel services={services} onCreate={() => setServiceOpen(true)} onDelete={deleteService} />}
        {tab === 'apis' && <ApiPanel apis={apis} services={services} onCreate={() => setApiOpen(true)} />}
        {tab === 'components' && <ComponentsCatalog />}
      </main>
    </div>

    <Dialog open={serviceOpen} onOpenChange={setServiceOpen} title="Create MongoDB Service" footer={<div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setServiceOpen(false)}>Cancel</Button><Button onClick={createService}>Create Service</Button></div>}>
      <div className="space-y-5">
        <div className="grid gap-4 md:grid-cols-2"><div><Label>Name</Label><Input value={serviceForm.name} onChange={e => setServiceForm(v=>({...v,name:e.target.value}))}/></div><div><Label>Mongo Collection</Label><Input value={serviceForm.collection} onChange={e => setServiceForm(v=>({...v,collection:e.target.value}))}/></div></div>
        <div className="rounded-lg border"><div className="flex items-center justify-between border-b px-4 py-3"><div><div className="font-medium">Fields</div><div className="text-xs text-slate-500">MongoDB-backed fields used by CRUD and APIs.</div></div><Badge>{serviceForm.fields.length} fields</Badge></div>
          <div className="p-4 space-y-2">{serviceForm.fields.map((f,i) => <div key={`${f.name}-${i}`} className="grid grid-cols-[1fr_120px_70px_70px_36px] items-center gap-2 rounded-md bg-slate-50 p-2 text-sm"><span className="font-medium">{f.name}</span><Badge>{f.type}</Badge><span className="text-xs">{f.required?'required':'optional'}</span><span className="text-xs">{f.unique?'unique':''}</span><button onClick={()=>setServiceForm(v=>({...v,fields:v.fields.filter((_,idx)=>idx!==i)}))} className="text-red-500">×</button></div>)}</div>
          <div className="grid gap-2 border-t p-4 md:grid-cols-[1.3fr_0.8fr_auto_auto]"><Input placeholder="fieldName" value={editingField.name} onChange={e=>setEditingField(v=>({...v,name:e.target.value}))}/><Select value={editingField.type} onChange={e=>setEditingField(v=>({...v,type:e.target.value}))}>{fieldTypes.map(t=><option key={t}>{t}</option>)}</Select><Button variant={editingField.required?'default':'outline'} size="sm" onClick={()=>setEditingField(v=>({...v,required:!v.required}))}>Required</Button><Button variant="outline" size="sm" onClick={addField}>Add</Button></div>
        </div>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-6 text-sm">{Object.entries(serviceForm.crud || {}).map(([key,val])=><label key={key} className="flex items-center gap-2"><input type="checkbox" checked={val} onChange={e=>setServiceForm(v=>({...v,crud:{...v.crud,[key]:e.target.checked}}))}/>{key}</label>)}</div>
      </div>
    </Dialog>

    <Dialog open={apiOpen} onOpenChange={setApiOpen} title="Create API Definition" footer={<div className="flex justify-end gap-2"><Button variant="outline" onClick={()=>setApiOpen(false)}>Cancel</Button><Button onClick={createApi}>Save API</Button></div>}>
      <div className="space-y-5">
        <div className="grid gap-4 md:grid-cols-3"><div><Label>Service</Label><Select value={apiForm.serviceId} onChange={e=>setApiForm(v=>({...v,serviceId:e.target.value}))}>{services.map(s=><option key={s._id} value={s._id}>{s.name}</option>)}</Select></div><div><Label>Method</Label><Select value={apiForm.method} onChange={e=>setApiForm(v=>({...v,method:e.target.value}))}>{['GET','POST','PUT','PATCH','DELETE'].map(m=><option key={m}>{m}</option>)}</Select></div><div><Label>Path (optional)</Label><Input placeholder="/api/runtime/users" value={apiForm.path} onChange={e=>setApiForm(v=>({...v,path:e.target.value}))}/></div></div>
        <div><Label>Select fields for GET</Label><div className="mt-2 grid grid-cols-2 gap-2 md:grid-cols-4">{(services.find(s=>s._id===apiForm.serviceId)?.fields || []).map(f=><label key={f.name} className="flex items-center gap-2 rounded border bg-slate-50 px-3 py-2 text-sm"><input type="checkbox" checked={apiForm.fields.includes(f.name)} onChange={e=>setApiForm(v=>({...v,fields:e.target.checked?[...v.fields,f.name]:v.fields.filter(x=>x!==f.name)}))}/>{f.name}<Badge>{f.type}</Badge></label>)}</div></div>
        <div><Label>Query capabilities</Label><div className="mt-2 flex flex-wrap gap-3">{['search','filter','sort','limit','skip'].map(key=><label key={key} className="flex items-center gap-2 text-sm"><Switch checked={apiForm[key]} onCheckedChange={v=>setApiForm(x=>({...x,[key]:v}))}/>{key}</label>)}</div></div>
      </div>
    </Dialog>
  </div>;
}

function Overview({ project, counts, services, apis }) {
  return <div className="space-y-6"><div><div className="text-sm text-slate-500">Configuration-driven application platform</div><h1 className="mt-1 text-3xl font-bold">{project.name}</h1><p className="mt-2 max-w-3xl text-slate-600">Configure UI, pages, services, CRUD, MongoDB fields and API behavior from /next-dev. Runtime renders the saved configuration.</p></div>
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{[["Services",counts.services,"Boxes"],["API Definitions",counts.apis,"Webhook"],["UI Categories",counts.categories,"PanelsTopLeft"],["Catalog Items",counts.items,"Blocks"]].map(([label,value,icon])=><Card key={label}><CardContent className="p-5"><div className="flex items-center justify-between"><div className="text-sm text-slate-500">{label}</div><Icon name={icon} className="text-blue-600"/></div><div className="mt-2 text-3xl font-bold">{value}</div></CardContent></Card>)}</div>
    <div className="grid gap-5 lg:grid-cols-2"><Card><CardHeader><CardTitle>Configured Services</CardTitle><CardDescription>MongoDB collections and CRUD capabilities.</CardDescription></CardHeader><CardContent><div className="space-y-3">{services.length ? services.map(s=><div key={s._id} className="flex items-center justify-between rounded-lg border px-4 py-3"><div><div className="font-medium">{s.name}</div><div className="text-xs text-slate-500">{s.collection} • {s.fields?.length || 0} fields</div></div><Badge>MongoDB</Badge></div>) : <div className="text-sm text-slate-500">No services yet.</div>}</div></CardContent></Card>
      <Card><CardHeader><CardTitle>API Definitions</CardTitle><CardDescription>GET/POST/PUT/PATCH/DELETE definitions created from the UI.</CardDescription></CardHeader><CardContent><div className="space-y-3">{apis.length ? apis.map(a=><div key={a._id} className="flex items-center justify-between rounded-lg border px-4 py-3"><div><div className="font-medium">{a.method} {a.path}</div><div className="text-xs text-slate-500">{a.serviceName}</div></div><Badge>config</Badge></div>) : <div className="text-sm text-slate-500">Create an API from API Builder.</div>}</div></CardContent></Card></div>
  </div>;
}

function ProjectSettings({ project, setProject }) {
  const update = (key, value) => setProject(p => ({ ...p, [key]: value }));
  return <div className="space-y-6"><div><h1 className="text-2xl font-bold">Project Settings</h1><p className="text-sm text-slate-500">Everything below becomes stored project configuration.</p></div>
    <Card><CardHeader><CardTitle>Identity</CardTitle></CardHeader><CardContent className="grid gap-4 md:grid-cols-2"><div><Label>Project name</Label><Input value={project.name} onChange={e=>update('name',e.target.value)}/></div><div><Label>Slug</Label><Input value={project.slug} onChange={e=>update('slug',e.target.value)}/></div></CardContent></Card>
    <Card><CardHeader><CardTitle>Global theme</CardTitle><CardDescription>Primary values used by runtime components.</CardDescription></CardHeader><CardContent className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">{Object.keys(project.theme || {}).map(key=><div key={key}><Label>{key}</Label><Input value={project.theme[key]} onChange={e=>setProject(p=>({...p,theme:{...p.theme,[key]:e.target.value}}))}/></div>)}</CardContent></Card>
    <Card><CardHeader><CardTitle>Layout</CardTitle></CardHeader><CardContent className="grid gap-5 md:grid-cols-2">{[['sidebar','Sidebar'],['header','Header'],['footer','Footer']].map(([key,label])=><label key={key} className="flex items-center gap-3"><Switch checked={project.layout?.[key]} onCheckedChange={v=>setProject(p=>({...p,layout:{...p.layout,[key]:v}}))}/><span>{label}</span></label>)}<div><Label>Sidebar width</Label><Input type="number" value={project.layout?.sidebarWidth || 260} onChange={e=>setProject(p=>({...p,layout:{...p.layout,sidebarWidth:Number(e.target.value)}}))}/></div><div><Label>Navbar height</Label><Input type="number" value={project.layout?.navbarHeight || 64} onChange={e=>setProject(p=>({...p,layout:{...p.layout,navbarHeight:Number(e.target.value)}}))}/></div></CardContent></Card>
    <Card><CardHeader><CardTitle>Navigation</CardTitle><CardDescription>Route / dialog / drawer / API actions can be extended in this config.</CardDescription></CardHeader><CardContent className="space-y-3">{(project.navigation?.items || []).map((item,i)=><div key={item.id} className="grid gap-2 rounded-lg border p-3 md:grid-cols-[1fr_1fr_1fr_2fr]"><Input value={item.label} onChange={e=>setProject(p=>({...p,navigation:{...p.navigation,items:p.navigation.items.map((x,idx)=>idx===i?{...x,label:e.target.value}:x)}}))}/><Select value={item.action} onChange={e=>setProject(p=>({...p,navigation:{...p.navigation,items:p.navigation.items.map((x,idx)=>idx===i?{...x,action:e.target.value}:x)}}))}><option value="route">Route</option><option value="dialog">Dialog</option><option value="drawer">Drawer</option><option value="scroll">Scroll to section</option><option value="api">Trigger API</option></Select><Input value={item.route || ''} placeholder="route / action target" onChange={e=>setProject(p=>({...p,navigation:{...p.navigation,items:p.navigation.items.map((x,idx)=>idx===i?{...x,route:e.target.value}:x)}}))}/><div className="flex items-center gap-2 text-sm"><Badge>{item.icon}</Badge><Badge>{item.action}</Badge></div></div>)}</CardContent></Card>
  </div>;
}

function ServicesPanel({ services, onCreate, onDelete }) {
  return <div className="space-y-5"><div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold">Services & CRUD</h1><p className="text-sm text-slate-500">Each service maps to a MongoDB collection and reusable runtime API.</p></div><Button onClick={onCreate}><Icon name="Plus" size={16}/> Create Service</Button></div>
    <div className="grid gap-4 xl:grid-cols-2">{services.map(s=><Card key={s._id}><CardHeader><div className="flex items-start justify-between"><div><CardTitle>{s.name}</CardTitle><CardDescription>{s.collection} • {s.slug}</CardDescription></div><Badge>MongoDB</Badge></div></CardHeader><CardContent><div className="mb-4 flex flex-wrap gap-2">{(s.fields||[]).map(f=><Badge key={f.name}>{f.name}:{f.type}</Badge>)}</div><div className="flex flex-wrap gap-2">{Object.entries(s.crud||{}).map(([key,val])=><Badge key={key} className={val?'bg-blue-50 text-blue-700':'bg-slate-100 text-slate-400'}>{key}</Badge>)}</div><div className="mt-4 flex justify-end"><Button variant="destructive" size="sm" onClick={()=>onDelete(s._id)}><Icon name="Trash2" size={15}/> Delete</Button></div></CardContent></Card>)}{!services.length && <Card className="xl:col-span-2"><CardContent className="py-16 text-center text-slate-500">Create your first MongoDB service.</CardContent></Card>}</div>
  </div>;
}

function ApiPanel({ apis, services, onCreate }) {
  return <div className="space-y-5"><div className="flex items-center justify-between"><div><h1 className="text-2xl font-bold">API Builder</h1><p className="text-sm text-slate-500">Select a service, method, fields, query, sorting and limits.</p></div><Button disabled={!services.length} onClick={onCreate}><Icon name="Plus" size={16}/> Create API</Button></div><div className="space-y-3">{apis.map(api=><Card key={api._id}><CardContent className="p-4"><div className="flex items-center justify-between"><div><div className="font-semibold">{api.method} {api.path}</div><div className="mt-1 text-xs text-slate-500">{api.serviceName} • fields: {(api.fields||[]).join(', ') || 'all'}</div></div><div className="flex gap-2">{['search','filter','sort','limit','skip'].filter(k=>api[k]).map(k=><Badge key={k}>{k}</Badge>)}</div></div></CardContent></Card>)}{!apis.length && <Card><CardContent className="py-16 text-center text-slate-500">No API definitions yet.</CardContent></Card>}</div></div>;
}

function ComponentsCatalog() {
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(null);
  const filtered = catalog.map(c => ({ ...c, items: c.items.filter(i => !search || i.toLowerCase().includes(search.toLowerCase())) })).filter(c => c.items.length);
  return <div className="space-y-5"><div><h1 className="text-2xl font-bold">47 UI Categories</h1><p className="text-sm text-slate-500">Master component registry for the builder.</p></div><Input placeholder="Search component, pattern, or category…" value={search} onChange={e=>setSearch(e.target.value)}/><div className="grid gap-3 lg:grid-cols-2">{filtered.map((c)=><Card key={c.id}><button onClick={()=>setOpen(open===c.id?null:c.id)} className="flex w-full items-center justify-between p-4 text-left"><div><div className="font-semibold">{c.name}</div><div className="text-xs text-slate-500">{c.items.length} items</div></div><Icon name={open===c.id?'ChevronUp':'ChevronDown'} size={18}/></button>{open===c.id&&<CardContent className="pt-0"><div className="flex flex-wrap gap-2">{c.items.map(item=><Badge key={item}>{item}</Badge>)}</div></CardContent>}</Card>)}</div></div>;
}
