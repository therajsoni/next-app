'use client';
import * as Icons from 'lucide-react';
export default function Icon({ name, size = 18, className = '' }) {
  const C = Icons[name] || Icons.Circle;
  return <C size={size} className={className} />;
}
