'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import Icon from './Icon';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export default function RuntimePreview() {
  const [project, setProject] = useState(null);
  const [services, setServices] = useState([]);
  const [apis, setApis] = useState([]);
  useEffect(() => { Promise.all([fetch('/api/project').then(r=>r.json()),fetch('/api/services').then(r=>r.json()),fetch('/api/apis').then(r=>r.json())]).then(([p,s,a])=>{setProject(p);setServices(s);setApis(a);}); }, []);
  if (!project) return <div className="grid min-h-screen place-items-center">Loading preview…</div>;
  const nav = project.navigation?.items || [];
  return <div className="min-h-screen" style={{ background: project.theme?.background || '#f8fafc', color: project.theme?.foreground || '#0f172a' }}>
    <header className="border-b bg-white" style={{height: project.layout?.navbarHeight || 64}}><div className="mx-auto flex h-full max-w-[1440px] items-center gap-4 px-5"><div className="font-bold">{project.name}</div><nav className="hidden gap-1 md:flex">{nav.map(item=><Link key={item.id} href={item.route || '/preview'} className="rounded-md px-3 py-2 text-sm hover:bg-slate-100">{item.label}</Link>)}</nav><div className="ml-auto"><Link href="/next-dev"><Button variant="outline" size="sm"><Icon name="Settings" size={15}/> Builder</Button></Link></div></div></header>
    <main className="mx-auto max-w-[1440px] space-y-6 p-5 lg:p-7">
      <section><div className="text-sm text-slate-500">Runtime render from MongoDB configuration</div><h1 className="mt-1 text-3xl font-bold">Dashboard</h1></section>
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{[
        ['Services',services.length,'Boxes'],['API Definitions',apis.length,'Webhook'],['MongoDB Mode','ON','Database'],['UI Registry','47','PanelsTopLeft']
      ].map(([label,value,icon])=><Card key={label}><CardContent className="p-5"><div className="flex items-center justify-between text-sm text-slate-500">{label}<Icon name={icon} size={18}/></div><div className="mt-2 text-3xl font-bold">{value}</div></CardContent></Card>)}</section>
      <section className="grid gap-5 lg:grid-cols-2">{services.map(service=><Card key={service._id}><CardHeader><CardTitle>{service.name}</CardTitle></CardHeader><CardContent><div className="mb-4 text-sm text-slate-500">MongoDB collection: {service.collection}</div><div className="space-y-2">{service.fields?.map(field=><div key={field.name} className="flex items-center justify-between rounded-md border px-3 py-2 text-sm"><span>{field.name}</span><Badge>{field.type}</Badge></div>)}</div></CardContent></Card>)}</section>
      <section className="rounded-xl border bg-white p-5"><div className="font-semibold">Configured API routes</div><div className="mt-3 space-y-2">{apis.map(api=><div key={api._id} className="flex items-center justify-between rounded-md bg-slate-50 px-3 py-2 text-sm"><span>{api.method} {api.path}</span><span className="text-slate-500">{api.serviceName}</span></div>)}</div></section>
    </main>
    {project.layout?.footer && <footer className="border-t bg-white"><div className="mx-auto max-w-[1440px] px-5 py-6 text-sm text-slate-500">{project.footer?.text || 'Built with Next Dev Builder'}</div></footer>}
  </div>;
}
