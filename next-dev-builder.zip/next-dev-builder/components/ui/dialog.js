'use client';
export function Dialog({ open, onOpenChange, title, children, footer }) {
  if (!open) return null;
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onMouseDown={() => onOpenChange?.(false)}>
    <div className="w-full max-w-2xl rounded-2xl bg-white shadow-2xl" onMouseDown={(e) => e.stopPropagation()}>
      <div className="flex items-center justify-between border-b px-5 py-4"><h2 className="font-semibold">{title}</h2><button className="text-slate-400 hover:text-slate-900" onClick={() => onOpenChange?.(false)}>×</button></div>
      <div className="max-h-[70vh] overflow-y-auto p-5">{children}</div>
      {footer ? <div className="border-t px-5 py-4">{footer}</div> : null}
    </div>
  </div>;
}
