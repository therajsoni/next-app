import { cn } from '@/lib/utils';
export function Select({ className, ...props }) { return <select className={cn('h-10 w-full rounded-md border border-slate-200 bg-white px-3 text-sm outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100', className)} {...props} />; }
