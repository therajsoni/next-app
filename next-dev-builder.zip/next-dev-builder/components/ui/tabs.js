'use client';
export function Tabs({ value, onValueChange, children }) { return <div data-value={value} data-change={onValueChange}>{children}</div>; }
export function TabsList({ className = '', children }) { return <div className={`flex flex-wrap gap-1 rounded-lg bg-slate-100 p-1 ${className}`}>{children}</div>; }
export function TabsTrigger({ value, activeValue, onSelect, children }) { return <button onClick={() => onSelect?.(value)} className={`rounded-md px-3 py-2 text-sm font-medium ${activeValue === value ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}>{children}</button>; }
