import { cn } from '@/lib/utils';
export function Textarea({ className, ...props }) { return <textarea className={cn('min-h-24 w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm outline-none placeholder:text-slate-400 focus:border-blue-400 focus:ring-2 focus:ring-blue-100', className)} {...props} />; }
