export const defaultProject = {
  name: 'My Next Dev Project',
  slug: 'my-next-dev-project',
  theme: {
    primary: '#2563eb',
    background: '#f8fafc',
    foreground: '#0f172a',
    border: '#e2e8f0',
    radius: '12px'
  },
  layout: {
    sidebar: true,
    header: true,
    footer: true,
    sidebarWidth: 260,
    navbarHeight: 64,
    maxWidth: '1440px'
  },
  navigation: {
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard', action: 'route', route: '/' },
      { id: 'users', label: 'Users', icon: 'Users', action: 'route', route: '/users' },
      { id: 'services', label: 'Services', icon: 'Boxes', action: 'route', route: '/next-dev/services' },
      { id: 'components', label: 'Components', icon: 'PanelsTopLeft', action: 'route', route: '/next-dev/components' }
    ]
  },
  dashboard: {
    enabled: true,
    cards: [
      { label: 'Services', valueSource: 'serviceCount', icon: 'Boxes' },
      { label: 'APIs', valueSource: 'apiCount', icon: 'Webhook' },
      { label: 'Mongo Collections', valueSource: 'serviceCount', icon: 'Database' },
      { label: '47 UI Categories', valueSource: 'catalogCategories', icon: 'PanelsTopLeft' }
    ]
  },
  pages: [],
  sections: [],
  footer: {
    enabled: true,
    text: 'Built with Next Dev Builder'
  }
};
